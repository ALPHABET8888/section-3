# section 3- challenge #1

A Pen created on CodePen.io. Original URL: [https://codepen.io/xnjentxh-the-selector/pen/xxBZoEW](https://codepen.io/xnjentxh-the-selector/pen/xxBZoEW).

