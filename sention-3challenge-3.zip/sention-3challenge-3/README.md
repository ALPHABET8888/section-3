# sention 3 -challenge 3

A Pen created on CodePen.io. Original URL: [https://codepen.io/xnjentxh-the-selector/pen/xxBOdGx](https://codepen.io/xnjentxh-the-selector/pen/xxBOdGx).

