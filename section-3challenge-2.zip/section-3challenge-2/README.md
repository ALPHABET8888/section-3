# section 3- challenge #2

A Pen created on CodePen.io. Original URL: [https://codepen.io/xnjentxh-the-selector/pen/OJqNqbY](https://codepen.io/xnjentxh-the-selector/pen/OJqNqbY).

